
public class Position {
	
	private int x;
	private int y;
	
	public Position(int pos_x, int pos_y) {
		x = pos_x;
		y = pos_y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setX(int n) {
		x = n;
	}
	
	public void setY(int n) {
		y = n;
	}

}
